<?php

namespace App\Http\Controllers;

use App\Interface\HasRoutes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Requests\Student\StudentByBarcodeRequest;
use App\Models\Student;

class StudentController extends Controller implements HasRoutes
{
    public static function getRoutes(): void
    {
        Route::post('student-by-barcode', [static::class, 'show']);
    }

    public function show(StudentByBarcodeRequest $request)
    {
        $barcode = $request->barcode;
        $student = Student::where('barcode', $barcode)->first();

        if ($student)
            return response()->json($student);
        return response()->json(['message' => 'Invalid student barcode'], 404);
    }
}
