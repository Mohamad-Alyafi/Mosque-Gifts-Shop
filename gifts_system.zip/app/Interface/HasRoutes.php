<?php

namespace App\Interface;

interface HasRoutes
{
    public static function getRoutes(): void;
}
